import { Agent } from "undici";
/**
 * Custom fetch with disabled body timeout.
 *
 * Node.js's built-in fetch (undici) has a default bodyTimeout of 300s (5 min).
 * When an LLM streams tool-call arguments, some providers (e.g. vLLM) buffer the
 * entire JSON and flush it at the end, creating a data gap that exceeds 5 minutes
 * and triggers UND_ERR_BODY_TIMEOUT ("terminated").
 *
 * This fetch disables that timeout so long-running streaming responses aren't killed.
 */
const dispatcher = new Agent({ bodyTimeout: 0, headersTimeout: 0 });
export const fetchWithNoBodyTimeout = (input, init) => {
    return fetch(input, { ...init, dispatcher });
};
//# sourceMappingURL=fetch.js.map